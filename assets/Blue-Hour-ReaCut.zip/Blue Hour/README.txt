Blue Hour is a sample project for ReaCut.

Open Blue Hour.reacut in ReaCut. Keep the media folder next to the project. The timeline contains three cuts and two editable sample captions. Press Play to preview or Export to make your own copy.

https://reacut.app/
