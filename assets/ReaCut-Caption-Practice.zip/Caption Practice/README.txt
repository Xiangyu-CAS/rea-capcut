ReaCut Caption Practice

1. Unzip the entire folder and open Caption Practice.reacut in ReaCut 0.9.0 or later on an Apple Silicon Mac. Keep the media folder next to the project.
2. Sign in to Codex in the Editing Agent and set up local speech recognition if needed.
3. Ask “Add English subtitles to this video.” Play the timeline to check the result. Edit the new subtitles in Captions.

Local speech setup
https://reacut.app/captions/

Blue Hour video by ReaCut. Synthetic Spanish narration generated with Piper (es_ES-davefx-medium, trained on CC0 audio).
https://huggingface.co/rhasspy/piper-voices/blob/5ec43b186ef915a195d3ddbcfd9916e76c503c3f/es/es_ES/davefx/medium/MODEL_CARD

https://reacut.app/#agent
