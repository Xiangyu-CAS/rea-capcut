ReaCut 字幕练习

1. 在 Apple 芯片 Mac 上解压整个文件夹，用 ReaCut 0.9.0 或更新版本打开 Caption Practice.reacut。保留同一目录下的 media 文件夹。
2. 在剪辑 Agent 中登录 Codex，按需配置本地语音识别。
3. 输入「给这个视频加英文字幕」。播放时间线检查效果，可以在字幕面板里编辑生成的字幕。

本地语音配置
https://github.com/Xiangyu-CAS/ReaCut/blob/v0.9.0/docs/LOCAL_SPEECH.md

视频来自 ReaCut 的《蓝调时刻》演示。西班牙语旁白由 Piper 的 es_ES-davefx-medium 模型生成，训练音频以 CC0 发布。
https://huggingface.co/rhasspy/piper-voices/blob/5ec43b186ef915a195d3ddbcfd9916e76c503c3f/es/es_ES/davefx/medium/MODEL_CARD

https://reacut.app/zh-cn/#agent
